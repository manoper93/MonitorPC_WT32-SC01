import os
import time
import serial
import wmi
import re

from ctypes import cast, POINTER
from comtypes import CLSCTX_ALL
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume

time.sleep(10)
#---------------------------------------------------------------------------------------------

def rx_tx_com_ports_from_file():
    try:
        with open('COM.txt', 'r') as file:
            com_port = file.readline().strip()  # Read the TX COM port
            return com_port
    except FileNotFoundError:
        logging.error("File 'COM.txt' not found.")
        return None, None

def sendData(cpuu, mempercused, cput, gpuperc, gpumem, gputemp, com_port):
    try:
        connection_tx = serial.Serial(com_port)
        data = f"{cpuu},{mempercused},{cput},{gpuperc},{gpumem},{gputemp}"
        connection_tx.write(data.encode())
        print("Tx:", data)
        connection_tx.close()
    except Exception as e:
        print(f"Error sending data: {e}")

def recetor(com_port):
    try:
        connection_rx = serial.Serial(com_port, timeout=0.07)  # Adjust the timeout as needed
        received_data = connection_rx.readline().decode('utf-8').strip()
        connection_rx.close()
        return received_data
    except Exception as e:
        print(f"Error in recetor: {e}")
        return "0"

def change_volume(increase=True, step=0.02):
    devices = AudioUtilities.GetSpeakers()
    interface = devices.Activate(
        IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
    volume = cast(interface, POINTER(IAudioEndpointVolume))

    current_volume = volume.GetMasterVolumeLevelScalar()
    if increase:
        new_volume = min(1.0, current_volume + step)
    else:
        new_volume = max(0.0, current_volume - step)

    volume.SetMasterVolumeLevelScalar(new_volume, None)

def mute_volume(mute=True):
    devices = AudioUtilities.GetSpeakers()
    interface = devices.Activate(
        IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
    volume = cast(interface, POINTER(IAudioEndpointVolume))

    if mute:
        volume.SetMute(1, None)  # 1 para silenciar
    else:
        volume.SetMute(0, None)  # 0 para desativar o mudo

#--------------------------------------------------------------------------------------------- loop
while True:
    com_port = rx_tx_com_ports_from_file()

    import wmi
    w = wmi.WMI(namespace="root\LibreHardwareMonitor")
    infoHardware = w.Sensor()

    cpuutil='nule'
    mem_perc_used='nule'
    cpu_temp='nule'
    gpu_perc='nule'
    gpu_mem='nule'
    gpu_memUsed='nule'
    gpu_memTotal='nule'
    gpu_temp='nule'

    for sensor in infoHardware:
        if sensor.SensorType==u'Load' and sensor.Name==u'CPU Total':
            cpuutil=int(sensor.Value)
            break
    for sensor in infoHardware:
        if sensor.SensorType==u'Load' and sensor.Name==u'Memory':
            mem_perc_used=int(sensor.Value)
            break
    for sensor in infoHardware:
        if sensor.SensorType==u'Temperature' and sensor.Name==u'CPU Package':
            cpu_temp=int(sensor.Value)
            break
    for sensor in infoHardware:
        if sensor.SensorType==u'Load' and sensor.Name==u'GPU Core':
            gpu_perc=int(sensor.Value)
            break
    for sensor in infoHardware:
        if sensor.Name==u'GPU Memory Used':
            gpu_memUsed=int(sensor.Value)
            break
    for sensor in infoHardware:
        if sensor.Name==u'GPU Memory Total':
            gpu_memTotal=int(sensor.Value)
            break
    for sensor in infoHardware:
        if sensor.SensorType==u'Temperature' and sensor.Name==u'GPU Core':
            gpu_temp=int(sensor.Value)
            break

    gpu_mem=int((gpu_memUsed*100) / gpu_memTotal)
    
    time.sleep(0.4)
    
    received_data = recetor(com_port)
    
    if received_data is not None:
        numeric_part = re.sub(r'\D', '', received_data)
        received_data = int(numeric_part) if numeric_part.isdigit() else None
        print("Rx:", received_data)
    else:
        print("Error receiving data.")
        

    if received_data == 1:
        print(f"-------------- Aumentar volume")
        change_volume(increase=True, step=0.1)
        time.sleep(0.2)
    if received_data == 2:
        print(f"-------------- Diminuir volume")
        change_volume(increase=False, step=0.1)
        time.sleep(0.2)
    if received_data == 3:
        print(f"-------------- Volume Mute")
        mute_volume(mute=False)
        time.sleep(0.2)
    if received_data == 4:
        print(f"-------------- Micro Ativo")
        time.sleep(0.2)
    if received_data == 5:
        print(f"-------------- Micro Mute")
        time.sleep(0.2)


    sendData(cpuutil, mem_perc_used, cpu_temp, gpu_perc, gpu_mem, gpu_temp, com_port)
    
    
                

